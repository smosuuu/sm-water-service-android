# SM RO WATER SERVICE Customer Android App

Native Firebase Authentication + Firestore are used through an Android bridge while the premium mobile UI remains in WebView.

Firebase `google-services.json` is included for package `com.smwater.service`.


Version 1.1.5 fixes login modal visibility: #authModal.hidden now explicitly uses display:none!important, so successful login closes the login screen and shows the app.
