package com.smwater.service;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.Window;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window=getWindow();
        window.setStatusBarColor(Color.rgb(246,250,252));
        window.setNavigationBarColor(Color.WHITE);
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        auth=FirebaseAuth.getInstance();
        db=FirebaseFirestore.getInstance();

        webView=new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient(){ @Override public void onPageFinished(WebView view,String url){ super.onPageFinished(view,url); FirebaseUser u=auth.getCurrentUser(); if(u!=null) js("window.nativeAuthResult(true,"+q("Welcome back.")+","+q(u.getUid())+","+q(u.getEmail()==null?"":u.getEmail())+")"); }});
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        webView.addJavascriptInterface(new NativeFirebase(), "AndroidFirebase");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private void js(String code){
        runOnUiThread(() -> webView.evaluateJavascript(code,null));
    }
    private static String q(String s){
        if(s==null)return "";
        return JSONObject.quote(s);
    }
    private String errorMessage(Exception e){
        String m=e.getMessage();
        if(m==null)return "Something went wrong. Please try again.";
        if(m.toLowerCase().contains("password is invalid") || m.toLowerCase().contains("no user record")) return "Email ya password galat hai.";
        if(m.toLowerCase().contains("email address is badly formatted")) return "Email address sahi format me enter karo.";
        if(m.toLowerCase().contains("already in use")) return "Is email ka account already hai. Login tab use karo.";
        return m;
    }

    public class NativeFirebase {
        @JavascriptInterface public void login(String email,String password){
            runOnUiThread(() -> auth.signInWithEmailAndPassword(email.trim().toLowerCase(),password)
                .addOnSuccessListener(r -> sendAuth(true,"Login successful.",r.getUser()))
                .addOnFailureListener(e -> sendAuth(false,errorMessage(e),null)));
        }
        @JavascriptInterface public void signup(String email,String password,String name,String phone){
            runOnUiThread(() -> auth.createUserWithEmailAndPassword(email.trim().toLowerCase(),password)
                .addOnSuccessListener(r -> {
                    FirebaseUser u=r.getUser();
                    if(u==null){sendAuth(false,"Account create nahi hua.",null);return;}
                    Map<String,Object> data=new HashMap<>();
                    data.put("uid",u.getUid()); data.put("email",u.getEmail()==null?email:u.getEmail());
                    data.put("name",name); data.put("phone",phone); data.put("online",true);
                    data.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                    data.put("lastSeenAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
                    db.collection("customers").document(u.getUid()).set(data)
                        .addOnCompleteListener(x -> sendAuth(true,"Account created successfully.",u));
                })
                .addOnFailureListener(e -> sendAuth(false,errorMessage(e),null)));
        }
        @JavascriptInterface public void resetPassword(String email){
            runOnUiThread(() -> auth.sendPasswordResetEmail(email.trim().toLowerCase())
                .addOnSuccessListener(v -> js("window.nativeResetResult(true,"+q("Reset link email par bhej diya gaya hai. Inbox aur Spam check karo.")+")"))
                .addOnFailureListener(e -> js("window.nativeResetResult(false,"+q(errorMessage(e))+")")));
        }
        @JavascriptInterface public void logout(){
            auth.signOut();
            js("window.nativeLogoutResult && window.nativeLogoutResult()" );
        }
        @JavascriptInterface public void saveOrder(String name,String phone,String address,String qty,String total,String payment,String note){
            FirebaseUser u=auth.getCurrentUser();
            if(u==null){js("window.nativeOrderResult(false,'Login required')");return;}
            String orderId="SM-"+new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(new java.util.Date())+"-"+java.util.UUID.randomUUID().toString().substring(0,6).toUpperCase(java.util.Locale.US);
            Map<String,Object> o=new HashMap<>();
            o.put("orderId",orderId); o.put("userId",u.getUid()); o.put("customerName",name); o.put("email",u.getEmail()==null?"":u.getEmail());
            o.put("phone",phone); o.put("address",address); o.put("total",parseInt(total)); o.put("paymentMethod",payment); o.put("note",note); o.put("status","New");
            List<Map<String,Object>> items=new ArrayList<>(); Map<String,Object> item=new HashMap<>();
            item.put("name","20L RO Jar"); item.put("qty",parseInt(qty)); item.put("price",20); items.add(item); o.put("items",items);
            o.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
            db.collection("orders").document(orderId).set(o)
                .addOnSuccessListener(v -> js("window.nativeOrderResult(true,"+q(orderId)+")"))
                .addOnFailureListener(e -> js("window.nativeOrderResult(false,"+q(errorMessage(e))+")"));
        }
        @JavascriptInterface public void loadOrders(){
            FirebaseUser u=auth.getCurrentUser();
            if(u==null){js("window.nativeOrdersResult(false,[],'Login required')");return;}
            db.collection("orders").whereEqualTo("userId",u.getUid()).get()
                .addOnSuccessListener(s -> {
                    StringBuilder a=new StringBuilder("[");
                    boolean first=true;
                    for(DocumentSnapshot d:s.getDocuments()){
                        if(!first)a.append(","); first=false;
                        Map<String,Object> m=d.getData();
                        JSONObject j=new JSONObject();
                        try{
                            j.put("id",d.getId()); j.put("orderId",m.get("orderId")); j.put("customerName",m.get("customerName"));
                            j.put("phone",m.get("phone")); j.put("address",m.get("address")); j.put("total",m.get("total")); j.put("paymentMethod",m.get("paymentMethod")); j.put("status",m.get("status"));
                            Object ct=m.get("createdAt"); j.put("createdAt",ct instanceof Timestamp?((Timestamp)ct).toDate().getTime():0);
                            j.put("items",m.get("items"));
                        }catch(Exception ignored){}
                        a.append(j.toString());
                    }
                    a.append("]");
                    js("window.nativeOrdersResult(true,"+a+",'')");
                })
                .addOnFailureListener(e -> js("window.nativeOrdersResult(false,[],"+q(errorMessage(e))+")"));
        }
        @JavascriptInterface public void saveProfile(String name,String phone){
            FirebaseUser u=auth.getCurrentUser(); if(u==null)return;
            Map<String,Object> d=new HashMap<>(); d.put("uid",u.getUid()); d.put("email",u.getEmail()==null?"":u.getEmail()); d.put("name",name); d.put("phone",phone); d.put("online",true); d.put("lastSeenAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
            db.collection("customers").document(u.getUid()).set(d,com.google.firebase.firestore.SetOptions.merge());
        }
        @JavascriptInterface public void loadProfile(){
            FirebaseUser u=auth.getCurrentUser(); if(u==null)return;
            db.collection("customers").document(u.getUid()).get().addOnSuccessListener(d->{
                Object n=d.get("name"),p=d.get("phone");
                js("window.nativeProfileResult("+q(n==null?"":String.valueOf(n))+","+q(p==null?"":String.valueOf(p))+","+q(u.getEmail()==null?"":u.getEmail())+")");
            });
        }
        private int parseInt(String s){try{return (int)Math.round(Double.parseDouble(String.valueOf(s).replace("₹","").trim()));}catch(Exception e){return 0;}}
        private void sendAuth(boolean ok,String message,FirebaseUser u){
            if(ok && u!=null) js("window.nativeAuthResult(true,"+q(message)+","+q(u.getUid())+","+q(u.getEmail()==null?"":u.getEmail())+")");
            else js("window.nativeAuthResult(false,"+q(message)+",'', '')");
        }
    }

    @Override public void onBackPressed(){ if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
