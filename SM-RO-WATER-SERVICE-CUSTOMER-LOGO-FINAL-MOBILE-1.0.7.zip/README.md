# SM RO WATER SERVICE — Customer Android App

Customer mobile app wrapped around the fixed Firebase-enabled customer interface.

Package: `com.smwater.service`

Build with GitHub Actions:
Actions → Build SM RO WATER SERVICE Customer APK → Run workflow.


Launcher icon: supplied SM RO WATER SERVICE logo. Version: 1.0.6 (versionCode 6).
