# SM RO WATER SERVICE — Mobile Build

This project is configured for Firebase Android package `com.smwater.service`.

## If building on a phone
AndroidIDE may fail if the Gradle wrapper is unavailable. This copy is intended to be built by GitHub Actions, so you do not need Android Studio or AndroidIDE.

### Phone-only build
1. Create/open a GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build SM RO Water Service APK**.
5. Tap **Run workflow**.
6. After the workflow completes, open the run and download the artifact named `SM-RO-WATER-SERVICE-debug`.
