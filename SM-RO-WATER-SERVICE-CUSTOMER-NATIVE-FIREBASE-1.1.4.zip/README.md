# SM RO WATER SERVICE Customer Android App

Native Firebase Authentication + Firestore are used through an Android bridge while the premium mobile UI remains in WebView.

Firebase `google-services.json` is included for package `com.smwater.service`.
